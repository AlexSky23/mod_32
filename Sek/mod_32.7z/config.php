<?php

// API VK
define('VK_ID', '7865539');
define('VK_SECRET', 'vQ6zfyQOYL8Awl05JYz1');
define('VK_URL', 'http://application.local/');